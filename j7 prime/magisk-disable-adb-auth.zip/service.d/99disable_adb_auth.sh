#!/system/bin/sh
setprop ro.adb.secure 0
setprop ro.secure 0
setprop service.adb.tcp.port 5555
stop adbd
start adbd
